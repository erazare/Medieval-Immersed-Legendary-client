
### Fixed

- farm animal collision was not re-enabled when the setting was turned off (thanks to [@RosyBuilds](https://www.planetminecraft.com/member/rosybuilds/))
- players' death items could be deleted during a lag clear
