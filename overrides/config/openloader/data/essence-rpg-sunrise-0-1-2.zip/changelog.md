===The resource pack HAS been updated with this update!===
===Current RP Version: v1.16===
===Minecraft Compatibility: 1.19.4===

Sunrise 0.0.1.2 "Dawn" Changelog:

Mob Variants:
    -Creepers now have a third custom mob variant!
        -Reeker: These creepers stink so bad, they can't explode! But man, do they reek... Get too close, and instead of blowing up, they release a continuous cloud of toxic fumes which ignore armor and deal massive guard break damage!

Technical: 
    -Added support for attribute-based damage versus players. Reekers currently use this system - if something seems fishy about it (besides their smell), let me know! Better to fix things early.
        -This might already be obsolete because of the /damage command in 1.19.4. However, this attribute damage system accepts variable input without the need for a function tree - I may end up keeping this system for the future, as ERPG very much needs variable input for things like damage.
    -Changed the augment table's font to utilize a space provider instead of an older method to achieve negative space.
        -Basically, if this change works, you won't notice anything wrong.

Balance:
    =Adjusted Upwind (Sneak):
        -Implemented a pierce limit of 3 for the harmful enemy tossing.
        =Players are no longer effected by the harmful toss, and are instead given the same effect that the caster receives.
        =Split the empowerment into grounded and aerial variants:
            =When used on the ground, act normally (with the balance changes listed above)
            -When used in the air, provides the caster with weaker levitation, and nearby players with no levitation.
            +When used in the air, provides the caster and nearby players with a temporary (2.5 second) speed bonus. Hit the ground running!
        Developer Commentary: Though chaining together sneakwinds to fly was one of my favorite things about the empowerment, I hadn't considered that it could be used to traverse the End with absolutely no safety risk. I wasn't satisfied to just nerf this ability, so I also provide players who use it with the choice to use it for bursts of movement speed on top of the existing fall damage negation. Changes to Upwind's interactions with players have been made in anticipation of the upcoming (but still distant) arena content. Better to test changes now, so they can get adjusted before the arena's release!

Misc:
    -Wisps have their model back! Unfortunately it doesn't look as good in motion as it did previously, though it's better than nothing. Mojang, please give Vex back the ability to display their headgear item.
    -All existing relic items except for Malaeus Tidebender are now denoted as "Sunset Relics" on the item card.
        -Going forward, relic items will have a different design approach - details aren't quite set in stone yet, but expect relics to be less static going forward.
        -If you do some digging in the code, you'll be able to preview the new system! Nothing *entirely* functional yet, though.
    -Updated the page 1 info prompt in the Empowerer to specify that binding handedness refers to what item slot your book needs to go in.

Hotfixes:
    -Updated the resource pack's version of ObjMC - grasses, ores, etc. should no longer have gross black outlining from a distance.
        -Thanks HahHujanApi from the Discord server for reporting this one!
    -Base movement speed granted via the Speed imbuement should no longer reset on login. 
        -Thanks TinCat from the Discord server for reporting this one!